"""
source init file
"""
FILE_OUT = open('log_file.txt', 'w')
FILE_OUT.close()
