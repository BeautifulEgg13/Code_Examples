"""
Primary testing executable
"""
import nose2

nose2.discover()
