//Database Term Project By Derek Edwards and Alex Houston
Gui Design and View controls By Derek Edwards
Controller and Database Design By Alex Houston

//Description:
Simple C# GUI that uses an SQL database to provide an Uber-like service
- User can register as a driver or a rider and be added to the database
- Riders can submit requests to the database to be picked up at a specific location and time
- Drivers can browse unfulfilled requests and accept at convenvience
- Riders can submit payment when Driver fulfills their request

//RULES
A driver may have only 1 car 
A rider may have only 1 credit card 